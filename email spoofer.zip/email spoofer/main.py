import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import traceback

def send_mail(receiver_email, spoofed_email, spoofed_name, message, subject, smtp_host, smtp_port, smtp_username, smtp_password, is_html=False):
    try:
        msg = MIMEMultipart("alternative")
        msg['From'] = f"{spoofed_name} <{spoofed_email}>"
        msg['To'] = receiver_email
        msg['Subject'] = subject

        if is_html:
            with open(message, 'r') as file:
                html_content = file.read()
            body = MIMEText(html_content, 'html')
        else:
            body = MIMEText(message, 'plain')

        msg.attach(body)

        server = smtplib.SMTP(smtp_host, smtp_port)
        server.starttls()
        server.login(smtp_username, smtp_password)
        text = msg.as_string()
        server.sendmail(spoofed_email, receiver_email, text)
        server.quit()

        print('Spoofed Email sent successfully to ' + str(receiver_email) + ' from ' + str(spoofed_name))
    except Exception as e:
        print(traceback.format_exc())

# Get user input
receiver_email = input('Enter the receiver\'s email address: ')
spoofed_email = input('Enter the spoofed email address: ')
spoofed_name = input('Enter the spoofed name: ')
subject = input('Enter the subject: ')

# Ask the user whether they want to send plain text or HTML
is_html = input('Do you want to send HTML email? (yes/no): ').lower() == 'yes'

# Get the message content based on user preference
if is_html:
    html_file_path = input('Enter the path to the HTML file: ')
    # Get SMTP settings from the user
    smtp_host = input('Enter SMTP host: ')
    smtp_port = int(input('Enter SMTP port: '))
    smtp_username = input('Enter SMTP username: ')
    smtp_password = input('Enter SMTP password: ')
    # Invoke send_mail to send email
    send_mail(receiver_email, spoofed_email, spoofed_name, html_file_path, subject, smtp_host, smtp_port, smtp_username, smtp_password, is_html)
else:
    message = input('Enter the plain text message: ')
    # Get SMTP settings from the user
    smtp_host = input('Enter SMTP host: ')
    smtp_port = int(input('Enter SMTP port: '))
    smtp_username = input('Enter SMTP username: ')
    smtp_password = input('Enter SMTP password: ')
    # Invoke send_mail to send email
    send_mail(receiver_email, spoofed_email, spoofed_name, message, subject, smtp_host, smtp_port, smtp_username, smtp_password, is_html)
